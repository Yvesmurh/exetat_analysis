import os

from exetat_dashboard.queries.helpers import get_connection


# ---------------------------------------------------------------------------
# App constants
# ---------------------------------------------------------------------------
DATA_AVAILABLE = False
try:
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT DISTINCT years FROM exetat_entry ORDER BY years")
            AVAILABLE_YEARS = [row[0] for row in cursor.fetchall()]

        DEFAULT_YEAR = 2023
        DEFAULT_OPTION = "Toutes les options"

        with conn.cursor() as cursor:
            cursor.execute("SELECT option_name FROM options ORDER BY option_name")
            OPTIONS_LIST = ["Toutes les options"] + [row[0] for row in cursor.fetchall()]

        with conn.cursor() as cursor:
            cursor.execute("SELECT name FROM pr_after_reform26 ORDER BY name")
            PROVINCES_26 = [row[0] for row in cursor.fetchall()]
        DATA_AVAILABLE = bool(AVAILABLE_YEARS)
    finally:
        try:
            conn.close()
        except Exception:
            pass
except Exception as exc:
    # If the DB is unavailable at import time, provide safe defaults so the
    # dashboard can still be imported and unit-tested without a running DB.
    print("Warning: exetat_dashboard.config could not initialize from DB:", exc)
    AVAILABLE_YEARS = []
    DEFAULT_YEAR = 2023
    DEFAULT_OPTION = "Toutes les options"
    OPTIONS_LIST = [DEFAULT_OPTION]
    PROVINCES_26 = []

# ---------------------------------------------------------------------------
# Theme — shared calm, high-contrast education palette.
# Keep these values aligned with the CSS tokens in assets/style.css.
# ---------------------------------------------------------------------------
COLORS = {
    "primary": "#245EA8", "primary_dark": "#173E70",
    "primary_light": "#EDF4FC", "success": "#176B48",
    "danger": "#B23832", "text": "#192B40", "muted": "#56677C",
    "bg": "#F4F7FB", "card_bg": "#FFFFFF", "border": "#DDE5EE",
}
MAP_COLORSCALE = [
    [0.0, "#EDF4FC"], [0.25, "#BED6EE"], [0.5, "#73A4D4"],
    [0.75, "#3674B4"], [1.0, "#173E70"],
]

# Buckets for the "Success Rate by Range" donut — keep in sync with any
# GROUP BY / CASE WHEN bucketing you do in queries/province.py
SUCCESS_RATE_BUCKETS = [
    {"label": "Excellent (≥ 0.31)", "min": 0.31, "max": 1.01, "color": "#173E70"},
    {"label": "Good (0.27 – 0.31)", "min": 0.27, "max": 0.31, "color": "#3674B4"},
    {"label": "Average (0.23 – 0.27)", "min": 0.23, "max": 0.27, "color": "#73A4D4"},
    {"label": "Low (0.19 – 0.23)", "min": 0.19, "max": 0.23, "color": "#BED6EE"},
    {"label": "Very Low (≤ 0.19)", "min": 0.0, "max": 0.19, "color": "#EDF4FC"},
]

STUDENT_PERCENTAGE_BUCKETS = [
    {"label": "50-59%", "color": "#BED6EE"},
    {"label": "60-69%", "color": "#91B9DF"},
    {"label": "70-79%", "color": "#5E95C8"},
    {"label": "80-89%", "color": "#3674B4"},
    {"label": "90%+", "color": "#173E70"},
]
