"""
map.py
======

Choropleth mapping module for the EXETAT School Rankings Dashboard.

Builds Plotly choropleth figures of the DRC's 26 provinces from
`26provinces_features.json`. The GeoJSON uses `properties.name` for
province names; matching is normalized so database naming differences
do not prevent a province from rendering.

Usage
-----
    from map import create_choropleth

    fig = create_choropleth(
        df,
        location_col="province",
        value_col="pass_rate",
    )
    fig.show()
"""

from __future__ import annotations

import json
import os
from typing import Optional

import pandas as pd
import plotly.graph_objects as go

from exetat_dashboard.utils.province_names import normalize_province_name

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
# __file__-anchored so this works regardless of the caller's cwd
# (consistent with the BASE_DIR pattern already used elsewhere in the project).
#
# Layout: exetat_dashboard/figures/map.py + exetat_dashboard/data/26provinces_features.json
# The GeoJSON lives one level up from this file, in a sibling data/ folder.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
GEOJSON_PATH = os.path.join(BASE_DIR, "..", "data", "26provinces_features.json")

# Property in the geojson that (in theory) matches the DB's province naming
# (French, upper-case, e.g. "HAUT-UELE"). Kept for reference/back-compat —
# actual joining now goes through the normalized key below, since the
# hand-reconciled "province" property and the DB column are two
# independently-maintained strings that aren't guaranteed to agree
# byte-for-byte (accents, "-" vs " ", stray whitespace, casing...).
# Property used by the new GeoJSON file.
FEATURE_ID_KEY = "properties.name"

# The property injected by `load_geojson()` holding the *normalized* province
# key (see utils/province_names.normalize_province_name). This is what
# `create_choropleth`/`diagnose_matches` actually join on by default, so a
# single messy name on either side (DB or GeoJSON) no longer silently drops
# that province from the map.
NORMALIZED_FEATURE_ID_KEY = "properties.province_key"
_NORMALIZED_PROPERTY = "province_key"


def load_geojson(path: str = GEOJSON_PATH) -> dict:
    """Load the DRC provinces GeoJSON from disk.

    Also injects a `province_key` property into every feature: the
    normalized (accent-stripped, upper-cased, hyphen/space-insensitive)
    form of `properties.name`. This is what matching is actually done
    against — see NORMALIZED_FEATURE_ID_KEY.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"26provinces_features.json not found at {path}. "
            "map.py resolves this path relative to its own file location "
            "(BASE_DIR = dirname(__file__)) — if you moved map.py, either "
            "move the geojson alongside it or update GEOJSON_PATH."
        )
    with open(path, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    for feature in geojson.get("features", []):
        props = feature.setdefault("properties", {})
        props[_NORMALIZED_PROPERTY] = normalize_province_name(props.get("name"))

    return geojson


def diagnose_matches(
    df: pd.DataFrame,
    location_col: str = "province",
    geojson: Optional[dict] = None,
    geojson_path: str = GEOJSON_PATH,
    featureidkey: str = NORMALIZED_FEATURE_ID_KEY,
) -> None:
    """
    Debugging helper — prints which values in df[location_col] DO and DON'T
    match a feature in the geojson. Plotly silently drops any location that
    doesn't find an exact string match via featureidkey, which is why a
    handful of mismatched names can make most of the map disappear while
    the rest of the dashboard (fed by the same query) looks fine.

    By default this compares NORMALIZED values (see
    utils.province_names.normalize_province_name) — the same normalization
    `create_choropleth` uses to actually build the map — so this function's
    report matches what you'll really see rendered. Pass
    featureidkey="properties.name" to instead diagnose *raw* (pre-fix)
    values, e.g. to see the original mismatch that was breaking the map.

    Call this once from a notebook/shell with your real query's output:

        from exetat_dashboard.figures.map import diagnose_matches
        from exetat_dashboard.queries.province import get_province_stats
        df = get_province_stats(2023, None)
        diagnose_matches(df)
    """
    if geojson is None:
        geojson = load_geojson(geojson_path)

    # featureidkey is a dotted path like "properties.name"
    prop_name = featureidkey.split(".", 1)[1]
    normalized = prop_name == _NORMALIZED_PROPERTY

    geo_values = {f["properties"][prop_name] for f in geojson["features"]}
    raw_df_values = df[location_col].dropna().unique()
    if normalized:
        df_values = {normalize_province_name(v) for v in raw_df_values}
    else:
        df_values = set(raw_df_values)

    matched = df_values & geo_values
    unmatched_in_df = sorted(v for v in (df_values - geo_values) if v is not None)
    unmatched_in_geo = sorted(v for v in (geo_values - df_values) if v is not None)

    print(f"GeoJSON provinces: {len(geo_values)}")
    print(f"DataFrame provinces: {len(df_values)}")
    print(f"Matched: {len(matched)}")
    print(f"Unmatched: {len(unmatched_in_df) + len(unmatched_in_geo)}\n")

    if unmatched_in_df:
        print("In df but NOT found in geojson (won't render on the map):")
        for v in unmatched_in_df:
            print(f"  {v!r}")
        print()

    if unmatched_in_geo:
        print("In geojson but NOT found in df (will render with no data / blank):")
        for v in unmatched_in_geo:
            print(f"  {v!r}")


def create_choropleth(
    df: pd.DataFrame,
    location_col: str = "province",
    value_col: str = "value",
    geojson: Optional[dict] = None,
    geojson_path: str = GEOJSON_PATH,
    featureidkey: str = NORMALIZED_FEATURE_ID_KEY,
    colorscale: str = "YlGnBu",
    title: Optional[str] = None,
    colorbar_title: Optional[str] = None,
    hover_name_col: Optional[str] = None,
    hover_cols: Optional[list[str]] = None,
    hover_labels: Optional[dict[str, str]] = None,
    zmid: Optional[float] = None,
    selected_location: Optional[str] = None,
) -> go.Figure:
    """
    Build a choropleth map of the DRC's 26 provinces.

    Parameters
    ----------
    df : pd.DataFrame
        Data containing at least `location_col` and `value_col`.
        Values in `location_col` are matched to the GeoJSON's `name`
        property after normalization.
    location_col : str
        Column in `df` with province names.
    value_col : str
        Column in `df` with the numeric value to color by
        (e.g. pass rate, average score, number of schools).
    geojson : dict, optional
        Pre-loaded geojson dict. If omitted, loaded from `geojson_path`.
    geojson_path : str
        Path to the geojson file (defaults to the file next to this module).
    featureidkey : str
        Path within each geojson feature used to match `location_col`.
    colorscale : str
        Plotly colorscale name.
    title : str, optional
        Figure title.
    colorbar_title : str, optional
        Label for the color bar. Defaults to `value_col`.
    hover_name_col : str, optional
        Column to show as the hover title instead of the raw province code.
    hover_cols : list[str], optional
        Extra columns from `df` to show as additional lines in the hover
        tooltip (e.g. ["num_schools", "num_participants", "rate_change_pts"]).
    hover_labels : dict[str, str], optional
        Display label overrides for `hover_cols`, e.g. {"rate_change_pts": "YoY change (pts)"}.
        Columns not listed fall back to their raw column name.
    zmid : float, optional
        Center point of the colorscale (e.g. 0, for a diverging scale showing
        year-over-year change where positive/negative should diverge from white).
    selected_location : str, optional
        A value from `location_col` to visually highlight (thicker border)
        — e.g. the province currently picked in a filter dropdown.

    Returns
    -------
    go.Figure
    """
    if geojson is None:
        geojson = load_geojson(geojson_path)

    missing = {location_col, value_col} - set(df.columns)
    if missing:
        raise ValueError(f"df is missing required column(s): {missing}")

    from exetat_dashboard.config import COLORS
    from exetat_dashboard.figures.analytics import empty_figure
    from exetat_dashboard.figures.overview_cards import _fmt_int
    from html import escape

    if df.empty:
        return empty_figure("No province data available for the selected filters.")
    hover_labels = hover_labels or {}
    prop_name = featureidkey.split(".", 1)[1]
    normalized = prop_name == _NORMALIZED_PROPERTY
    location_values = df[location_col].map(normalize_province_name) if normalized else df[location_col]
    selected_key = normalize_province_name(selected_location) if normalized else selected_location
    percent = "rate" in value_col or "%" in (colorbar_title or "")
    hover_cols = hover_cols or []
    customdata = []
    for _, row in df.iterrows():
        values = []
        for col in hover_cols:
            value = row.get(col)
            if value is None or pd.isna(value):
                text = "Not available"
            elif "delta" in col:
                text = f"{float(value):+.2f} pts"
            elif col in ("schools", "participants", "successes"):
                text = _fmt_int(value)
            else:
                text = escape(str(value))
            values.append(text)
        customdata.append(values)
    extra = "".join(f"{escape(hover_labels.get(col, col))}: %{{customdata[{i}]}}<br>"
                    for i, col in enumerate(hover_cols))
    fig = go.Figure()
    # An explicit gray layer distinguishes no data from a measured 0%.
    all_locations = [f["properties"][prop_name] for f in geojson["features"]]
    all_names = [escape(f["properties"].get("name", "").title()) for f in geojson["features"]]
    fig.add_trace(go.Choropleth(
        geojson=geojson, locations=all_locations, z=[0] * len(all_locations),
        featureidkey=featureidkey, colorscale=[[0,"#E8EDF3"],[1,"#E8EDF3"]],
        showscale=False,
        marker_line_color=["#102B4D" if selected_key and loc == selected_key else "#98A9BB" for loc in all_locations],
        marker_line_width=[3 if selected_key and loc == selected_key else .8 for loc in all_locations],
        hovertext=all_names, hovertemplate="<b>%{hovertext}</b><br>No data available<extra></extra>",
    ))
    fig.add_trace(go.Choropleth(
        geojson=geojson, locations=list(location_values),
        z=[None if pd.isna(v) else float(v) for v in df[value_col]],
        featureidkey=featureidkey, colorscale=colorscale,
        zmin=0 if percent else None, zmax=100 if percent else None, zmid=zmid,
        marker_line_color=["#102B4D" if selected_key and loc == selected_key else "#FFFFFF" for loc in location_values],
        marker_line_width=[3 if selected_key and loc == selected_key else 1 for loc in location_values],
        colorbar=dict(title=dict(text="Success rate" if percent else colorbar_title or value_col,
                                font=dict(color=COLORS["muted"], size=12)),
                      thickness=12, len=.72, x=1.0, ticksuffix="%" if percent else "",
                      tickvals=[0,25,50,75,100] if percent else None,
                      tickfont=dict(color=COLORS["muted"], size=12), outlinewidth=0),
        hovertext=[escape(str(v).title()) for v in df[hover_name_col or location_col]],
        customdata=customdata,
        hovertemplate="<b>%{hovertext}</b><br>" + ("Success rate: %{z:.2f}%<br>" if percent else "%{z}<br>") + extra + "<extra></extra>",
    ))
    fig.update_geos(fitbounds="locations", visible=False, projection_type="mercator")
    fig.update_layout(
        title=title, autosize=True, margin=dict(l=12,r=55,t=40 if title else 10,b=12),
        geo=dict(bgcolor="rgba(0,0,0,0)"), paper_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Inter, Segoe UI, Arial, sans-serif", color=COLORS["text"], size=13),
        hoverlabel=dict(bgcolor="white", bordercolor=COLORS["primary"], font=dict(color=COLORS["text"],size=14)),
    )
    return fig
