"""Student score ranges: horizontal bars and exact counts, not pie slices."""
import math
import plotly.graph_objects as go
from exetat_dashboard.config import STUDENT_PERCENTAGE_BUCKETS
from exetat_dashboard.figures.analytics import _base_figure, empty_figure


def build_distribution_figure(df):
    if df is None or df.empty or "student_count" not in df or df["student_count"].sum() == 0:
        return empty_figure()
    labels = [b["label"] for b in reversed(STUDENT_PERCENTAGE_BUCKETS)]
    counts = df.set_index("bucket_label")["student_count"].reindex(labels, fill_value=0)
    fig = _base_figure()
    fig.add_trace(go.Bar(
        y=["90%+", "80–<90%", "70–<80%", "60–<70%", "50–<60%"], x=[int(v) for v in counts], orientation="h",
        marker_color=[b["color"] for b in reversed(STUDENT_PERCENTAGE_BUCKETS)],
        text=[f"{int(v):,}" for v in counts], textposition="outside", cliponaxis=False,
        hovertemplate="Score %{y}<br>%{x:,} recorded results<extra></extra>",
    ))
    fig.update_layout(margin=dict(l=72,r=48,t=20,b=55), bargap=.4,
                      xaxis=dict(title="Recorded student results", tickformat=",d", showgrid=True,
                                 gridcolor="#E8EDF3", dtick=max(1, math.ceil(float(counts.max())/5)), range=[0, max(1,float(counts.max())*1.25)]),
                      yaxis=dict(autorange="reversed", showgrid=False))
    return fig
