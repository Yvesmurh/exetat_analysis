"""Semantic province comparison table, with consistent unavailable values."""
import pandas as pd
from dash import html
from exetat_dashboard.figures.overview_cards import _fmt_int, _fmt_pct, _delta_badge
from exetat_dashboard.utils.province_names import normalize_province_name

TOP_N = 5


def ordered_provinces(df, order="highest"):
    if df is None or df.empty:
        return df
    key = "delta_vs_prev_year" if order == "decline" else "success_rate"
    return df.sort_values([key, "province"], ascending=[order != "highest", True], na_position="last")


def build_ranking_table(df, show_all=False, top_n=TOP_N, order="highest", selected=None, detailed=False):
    if df is None or df.empty:
        return html.Div("No province results available for the selected filters.", className="empty-state", role="status")
    visible = ordered_provinces(df, order)
    if not show_all:
        visible = visible.head(top_n)
    headers = ["Rank", "Province", "Success rate"]
    if detailed:
        headers += ["Schools", "Participants", "Successful students"]
    headers += ["Change (pts)"]
    rows = []
    for row in visible.itertuples():
        rate = None if pd.isna(row.success_rate) else float(row.success_rate) * 100
        values = [html.Td("—" if rate is None else str(row.rank)),
                  html.Th(str(row.province).title(), scope="row"),
                  html.Td(_fmt_pct(rate), className="analytics-score")]
        if detailed:
            values += [html.Td(_fmt_int(getattr(row, col, None))) for col in ("schools", "participants", "successes")]
        values += [html.Td(_delta_badge(row.delta_vs_prev_year))]
        chosen = selected and normalize_province_name(row.province) == normalize_province_name(selected)
        rows.append(html.Tr(values, className="selected-row" if chosen else ""))
    return html.Div(html.Table([
        html.Caption("Change from the preceding year in percentage points. Rank is based on success rate; missing rates are unranked."),
        html.Thead(html.Tr([html.Th(title, scope="col") for title in headers])),
        html.Tbody(rows),
    ], className="analytics-table"), className="analytics-table-scroll", tabIndex=0,
       **{"aria-label": "Province results table"})


def toggle_button_label(total_rows, show_all, top_n=TOP_N):
    if total_rows <= top_n:
        return None
    return f"Show first {top_n} provinces" if show_all else f"Show all {total_rows} provinces"
