"""Readable overview metrics and recorded option leaders."""
import math
from dash import html

# Existing imports retained; metric descriptions carry the meaning without icons.
_ICON_SCHOOL = _ICON_USERS = _ICON_CHECK = _ICON_TARGET = None
TOP_STUDENTS_PREVIEW_COUNT = 7


def _fmt_int(value):
    try:
        return f"{int(value):,}"
    except (TypeError, ValueError, OverflowError):
        return "—"


def _fmt_pct(value, decimals=2):
    try:
        return f"{float(value):.{decimals}f}%" if math.isfinite(float(value)) else "—"
    except (TypeError, ValueError):
        return "—"


def _delta_badge(delta, year=None):
    if delta is None or not math.isfinite(float(delta)):
        return html.Span("No previous-year comparison", className="delta-badge delta-neutral")
    arrow, css = ("↑", "delta-up") if delta > 0 else (("↓", "delta-down") if delta < 0 else ("→", "delta-neutral"))
    previous = str(int(year) - 1) if year is not None else "previous year"
    return html.Span(f"{arrow} {delta:+.2f} pts from {previous}", className=f"delta-badge {css}")


def _kpi_card(label, value, icon=None, extra=None, description=None):
    description = description or {
        "Total Schools": "Schools with recorded examination sessions.",
        "Total Options": "Educational options with recorded sessions.",
        "Total Participants": "Students registered as examination participants.",
        "Successful Students": "Participants recorded as having passed.",
        "Total Successful Students": "Participants recorded as having passed.",
    }.get(label, "Successful students as a percentage of participants.")
    label_content = [label]
    if "Rate" in label:
        label_content.append(html.Details([
            html.Summary("i", **{"aria-label": f"About {label.lower()}"}),
            html.P("Successful students ÷ participants × 100. A change of 1 percentage point means the rate increased or decreased by 1 on this scale."),
        ], className="metric-tip"))
    return html.Div([
        html.Div(label_content, className="kpi-label"),
        html.Div(value, className="kpi-value"),
        html.Div(description, className="kpi-description"),
        *([extra] if extra is not None else []),
    ], className="kpi-card")


def build_overview_cards(overview, year=None, province=None):
    overview = overview or {}
    if not overview or not (overview.get("total_participants") or overview.get("total_schools")):
        return html.Div("No data available for the selected filters.", className="empty-state", role="status")
    return html.Div([
        _kpi_card("Total Schools", _fmt_int(overview.get("total_schools"))),
        _kpi_card("Total Participants", _fmt_int(overview.get("total_participants"))),
        _kpi_card("Successful Students", _fmt_int(overview.get("total_successful"))),
        _kpi_card("Province Success Rate" if province else "National Success Rate",
                  _fmt_pct(overview.get("success_rate")),
                  extra=_delta_badge(overview.get("success_rate_delta_vs_prev_year"), year)),
    ], className="kpi-row")


def top_students_toggle_label(total_rows, show_all, preview_count=TOP_STUDENTS_PREVIEW_COUNT):
    if total_rows <= preview_count:
        return None
    return "Show top students only" if show_all else f"Show all {total_rows} option leaders"


def build_top_students_table(df, show_all=False, preview_count=TOP_STUDENTS_PREVIEW_COUNT):
    if df is None or df.empty:
        return html.Div("No student results available for the selected filters.", className="empty-state", role="status")
    visible = df if show_all else df.head(preview_count)
    rows = [html.Tr([
        html.Th(row.top_student_current or "—", scope="row"),
        html.Td(row.option_name or "—"),
        html.Td(_fmt_pct(row.top_percentage_current), className="analytics-score"),
        html.Td(_delta_badge(row.pts_change)),
    ]) for row in visible.itertuples()]
    return html.Div(html.Table([
        html.Caption("One best recorded score per option. Change compares this option's best score with the preceding year; it may concern a different student."),
        html.Thead(html.Tr([html.Th(s, scope="col") for s in ["Student", "Educational option", "Score", "Change from previous year"]])),
        html.Tbody(rows),
    ], className="analytics-table"), className="analytics-table-scroll", tabIndex=0,
        **{"aria-label": "Top performing students"})
