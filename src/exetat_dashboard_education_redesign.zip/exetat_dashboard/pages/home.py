"""Overview: key results → province comparison → trends → student results.

Callbacks retain existing query/figure boundaries. Apply commits one consistent
selection; national comparisons explicitly retain all provinces.
"""
import dash
import pandas as pd
from dash import Input, Output, State, dcc, html
from exetat_dashboard.config import (
    AVAILABLE_YEARS, DEFAULT_OPTION, DEFAULT_YEAR, OPTIONS_LIST, PROVINCES_26, MAP_COLORSCALE,
)
from exetat_dashboard.components.ui import card, field, loading, data_notice, metric_help, chart_values, graph_summary
from exetat_dashboard.figures.analytics import empty_state, empty_figure, build_scope_trend
from exetat_dashboard.figures.distribution import build_distribution_figure
from exetat_dashboard.figures.map import create_choropleth
from exetat_dashboard.figures.overview_cards import build_overview_cards, build_top_students_table, top_students_toggle_label
from exetat_dashboard.figures.ranking import build_ranking_table, toggle_button_label
from exetat_dashboard.figures.trend import build_trend_cards, build_trend_table
from exetat_dashboard.queries.overview import get_national_overview, get_top_students_by_option
from exetat_dashboard.queries.province import get_province_stats, get_student_percentage_distribution
from exetat_dashboard.queries.trends import get_province_trends, get_national_trend
from exetat_dashboard.utils.analytics_callbacks import safe_render, ERROR_MESSAGE

dash.register_page(__name__, path="/", name="Overview")
ALL_PROVINCES_LABEL = "Toutes les provinces"
INITIAL_YEAR = DEFAULT_YEAR if DEFAULT_YEAR in AVAILABLE_YEARS else (AVAILABLE_YEARS[-1] if AVAILABLE_YEARS else None)
INITIAL_FILTERS = {"year": INITIAL_YEAR, "province": ALL_PROVINCES_LABEL, "option": DEFAULT_OPTION}
TREND_YEARS = list(range(min(AVAILABLE_YEARS), max(AVAILABLE_YEARS)+1)) if AVAILABLE_YEARS else []


def _clean(value, all_label):
    return None if value in (None, "", all_label) else value


def _selection(data):
    data = data or INITIAL_FILTERS
    return data.get("year"), _clean(data.get("province"), ALL_PROVINCES_LABEL), data.get("option")


def _filters_row():
    return html.Section([
        html.Div([html.H2("Analysis filters"), html.Span("Choose your selection, then apply.")], className="filter-heading"),
        html.Div([
            field("year-dropdown", "Year", [{"label": str(y), "value": y} for y in AVAILABLE_YEARS], INITIAL_YEAR, placeholder="No years available"),
            field("province-dropdown", "Province", [{"label": "All provinces", "value": ALL_PROVINCES_LABEL}] +
                  [{"label": p.title(), "value": p} for p in PROVINCES_26], ALL_PROVINCES_LABEL),
            field("option-dropdown", "Educational option", [{"label": "All options" if o == DEFAULT_OPTION else o, "value": o} for o in OPTIONS_LIST], DEFAULT_OPTION),
            html.Button("Apply filters", id="apply-filters-btn", n_clicks=0, className="apply-filters-btn"),
            html.Button("Reset filters", id="reset-filters-btn", n_clicks=0, className="secondary-btn"),
        ], className="filters-row"),
        html.Div(id="filter-summary", className="filter-summary", role="status"),
    ], className="filter-panel", **{"aria-label": "Analysis filters"})


layout = html.Div([
    html.Div([
        html.Div([html.Div("DRC education data", className="eyebrow"),
                  html.H1("National overview", className="page-title"),
                  html.P("Understand examination results, compare provinces, and explore how performance is changing.", className="page-subtitle")]),
        html.Div([html.Span("Showing exam year"), html.Strong(id="active-year-label")], className="active-dataset"),
    ], className="dashboard-header"),
    html.Div([
        dcc.Link("For families: explore school results →", href="/schools"),
        html.A("For supervisors: compare provinces →", href="#province-comparison"),
        html.A("For policymakers: explore trends →", href="#performance-trends"),
    ], className="audience-links"),
    data_notice(),
    _filters_row(),
    html.Section([
        html.Div([html.H2(id="overview-heading"), html.P("Participation and examination outcomes")], className="section-heading"),
        loading(html.Div(id="overview-cards")),
    ], className="overview-section"),
    html.Div([
        card(2, "Performance across provinces", "Compare success rates across the country. The selected province is outlined.", [
            loading(dcc.Graph(id="province-map", figure=empty_figure(),
                              config={"displayModeBar": False, "responsive": True, "topojsonURL": "/assets/"},
                              responsive=True, className="map-graph")),
            html.Div([html.Span("Darker blue indicates a higher success rate."),
                      html.Span([html.Span(className="legend-swatch"), "No data"])], id="map-legend", className="map-footnote"),
            html.Details([html.Summary("View all province values"), loading(html.Div(id="map-table"))], className="chart-values"),
        ], id="province-comparison"),
        card(3, "Compare province results", "All provinces · selected year and educational option", [
            html.Div([html.Label("Sort by", htmlFor="ranking-order", id="ranking-order-label"),
                      dcc.Dropdown(id="ranking-order", options=[
                          {"label":"Highest success rate", "value":"highest"},
                          {"label":"Lowest success rate", "value":"lowest"},
                          {"label":"Largest decline", "value":"decline"},
                      ], value="highest", clearable=False, searchable=False, optionHeight=44)], className="comparison-controls"),
            loading(html.Div(id="ranking-insight", className="insight-note")),
            loading(html.Div(id="ranking-table-container")),
            html.Button("Show all provinces", id="ranking-toggle-btn", n_clicks=0, className="ranking-toggle-btn"),
        ]),
    ], className="overview-main-grid"),
    card(4, "How is performance changing over time?", "National success rate · selected option · all available years. Gaps indicate unavailable results.", [
        loading(dcc.Graph(id="national-trend", figure=empty_figure(), config={"displayModeBar":False}, responsive=True, className="trend-main-graph")),
        chart_values("national-trend-values"),
        html.Details([
            html.Summary("Explore trends for each province"),
            loading(html.Div(id="trend-cards-container")),
            html.Details([html.Summary("View province trend values"), loading(html.Div(id="province-trend-values"))], className="chart-values"),
        ], className="province-details"),
    ], id="performance-trends"),
    html.Div([
        card(5, "Student performance distribution", "Selected province and option · recorded results of 50% or higher", [
            loading(dcc.Graph(id="distribution-graph", figure=empty_figure(), config={"displayModeBar":False}, responsive=True, className="analytics-graph")),
            html.P("These ranges use the existing overview result population. School pages also show recorded scores below 50%.", className="supporting-text"),
            chart_values("distribution-values"),
        ]),
        card(6, "Top performing students", "Best recorded score for each educational option in this selection", [
            loading(html.Div(id="top-students-container")),
            html.Button("Show all option leaders", id="students-toggle-btn", n_clicks=0, className="ranking-toggle-btn"),
        ]),
    ], className="analytics-pair"),
    metric_help(),
    dcc.Store(id="applied-filters-store", data=INITIAL_FILTERS),
    dcc.Store(id="province-stats-store"),
    dcc.Store(id="ranking-show-all-store", data=False),
    dcc.Store(id="students-show-all-store", data=False),
], className="home-page")


@dash.callback(
    Output("applied-filters-store", "data"), Output("year-dropdown", "value"),
    Output("province-dropdown", "value"), Output("option-dropdown", "value"),
    Input("apply-filters-btn", "n_clicks"), Input("reset-filters-btn", "n_clicks"),
    State("year-dropdown", "value"), State("province-dropdown", "value"), State("option-dropdown", "value"),
    prevent_initial_call=True,
)
def _apply_filters(_apply, _reset, year, province, option):
    selection = dict(INITIAL_FILTERS) if dash.ctx.triggered_id == "reset-filters-btn" else {
        "year": year, "province": province, "option": option}
    return selection, selection["year"], selection["province"], selection["option"]


@dash.callback(Output("filter-summary", "children"), Input("applied-filters-store", "data"),
               Input("year-dropdown", "value"), Input("province-dropdown", "value"), Input("option-dropdown", "value"))
def _filter_summary(applied, year, province, option):
    chosen_year, chosen_province, chosen_option = _selection(applied)
    draft = {"year":year, "province":province, "option":option}
    label = f"{chosen_year or 'No year available'} · {chosen_province.title() if chosen_province else 'All provinces'} · {chosen_option if chosen_option != DEFAULT_OPTION else 'All options'}"
    return [html.Strong("Showing: "), label, html.Br(),
            "Changes are pending. Select Apply filters. " if draft != applied else "",
            "Totals and student results follow this selection. The map, province ranking and national trend compare all provinces."]


@dash.callback(Output("active-year-label", "children"), Output("overview-heading", "children"), Input("applied-filters-store", "data"))
def _render_active_year(selection):
    year, province, _ = _selection(selection)
    return str(year) if year is not None else "—", f"{province.title()} overview" if province else "National results at a glance"


@dash.callback(Output("province-stats-store", "data"), Input("applied-filters-store", "data"))
def _update_province_stats(selection):
    year, _, option = _selection(selection)
    if year is None:
        return {"records":[], "error":False}
    try:
        df = get_province_stats(year, option, raise_on_error=True)
        return {"records":df.astype(object).where(pd.notnull(df), None).to_dict("records"), "error":False}
    except Exception:
        return {"records":[], "error":True}


@dash.callback(Output("overview-cards", "children"), Input("applied-filters-store", "data"))
def _render_overview_cards(selection):
    year, province, option = _selection(selection)
    if year is None:
        return empty_state()
    return safe_render(lambda: get_national_overview(year, option, province, raise_on_error=True),
                       lambda data: build_overview_cards(data, year, province))


@dash.callback(Output("students-show-all-store", "data"), Input("students-toggle-btn", "n_clicks"),
               Input("applied-filters-store", "data"), State("students-show-all-store", "data"), prevent_initial_call=True)
def _toggle_students(_clicks, _selection, show_all):
    return not show_all if dash.ctx.triggered_id == "students-toggle-btn" else False


@dash.callback(Output("top-students-container", "children"), Output("students-toggle-btn", "children"),
               Output("students-toggle-btn", "style"), Input("applied-filters-store", "data"), Input("students-show-all-store", "data"))
def _render_top_students(selection, show_all):
    year, province, option = _selection(selection)
    hidden = {"display":"none"}
    if year is None:
        return empty_state(), "", hidden
    try:
        df = get_top_students_by_option(year, option, province, raise_on_error=True)
        label = top_students_toggle_label(len(df), show_all)
        return build_top_students_table(df, show_all), label or "", {} if label else hidden
    except Exception:
        return empty_state(ERROR_MESSAGE), "", hidden


@dash.callback(Output("national-trend", "figure"), Output("trend-cards-container", "children"),
               Output("province-trend-values", "children"), Input("applied-filters-store", "data"))
def _render_trend(selection):
    _, province, option = _selection(selection)
    national = safe_render(lambda: get_national_trend(TREND_YEARS, option),
                           lambda df: build_scope_trend(df, TREND_YEARS), figure=True)
    try:
        df = get_province_trends(PROVINCES_26, TREND_YEARS, option, raise_on_error=True)
        return national, build_trend_cards(df, province, TREND_YEARS), build_trend_table(df)
    except Exception:
        return national, empty_state(ERROR_MESSAGE), empty_state(ERROR_MESSAGE)


@dash.callback(Output("province-map", "figure"), Output("map-table", "children"),
               Input("province-stats-store", "data"), Input("applied-filters-store", "data"))
def _render_map(payload, selection):
    payload = payload or {}
    if payload.get("error"):
        return empty_figure(ERROR_MESSAGE), empty_state(ERROR_MESSAGE)
    df = pd.DataFrame(payload.get("records", []))
    _, province, _ = _selection(selection)
    if df.empty:
        return empty_figure("No province data available for the selected filters."), empty_state()
    df = df.assign(success_rate_pct=pd.to_numeric(df["success_rate"], errors="coerce") * 100)
    fig = create_choropleth(df, location_col="province", value_col="success_rate_pct",
                           hover_name_col="province", hover_cols=["schools","participants","successes","delta_vs_prev_year"],
                           hover_labels={"schools":"Schools", "participants":"Participants", "successes":"Successful students",
                                         "delta_vs_prev_year":"Change from previous year"},
                           colorscale=MAP_COLORSCALE, colorbar_title="Success rate (%)", selected_location=province)
    return fig, build_ranking_table(df, show_all=True, selected=province, detailed=True)


@dash.callback(Output("distribution-graph", "figure"), Input("applied-filters-store", "data"))
def _render_distribution(selection):
    year, province, option = _selection(selection)
    if year is None:
        return empty_figure()
    return safe_render(lambda: get_student_percentage_distribution(year, option, province, raise_on_error=True),
                       build_distribution_figure, figure=True)


@dash.callback(Output("ranking-show-all-store", "data"), Input("ranking-toggle-btn", "n_clicks"),
               Input("applied-filters-store", "data"), State("ranking-show-all-store", "data"), prevent_initial_call=True)
def _toggle_ranking(_clicks, _selection, show_all):
    return not show_all if dash.ctx.triggered_id == "ranking-toggle-btn" else False


@dash.callback(Output("ranking-table-container", "children"), Output("ranking-toggle-btn", "children"),
               Output("ranking-toggle-btn", "style"), Output("ranking-insight", "children"),
               Input("province-stats-store", "data"), Input("ranking-show-all-store", "data"),
               Input("ranking-order", "value"), Input("applied-filters-store", "data"))
def _render_ranking(payload, show_all, order, selection):
    payload = payload or {}
    if payload.get("error"):
        return empty_state(ERROR_MESSAGE), "", {"display":"none"}, "Province comparisons are currently unavailable."
    df = pd.DataFrame(payload.get("records", []))
    _, province, _ = _selection(selection)
    insight = "Select a year to compare available province results."
    if not df.empty:
        valid = df.dropna(subset=["success_rate"])
        if not valid.empty:
            lowest = valid.loc[valid.success_rate.idxmin()]
            insight = f"{str(lowest.province).title()} has the lowest reported success rate in this selection ({lowest.success_rate*100:.2f}%). Consider participation and local context when investigating."
        else:
            insight = "There are no available success rates for this selection."
    label = toggle_button_label(len(df), show_all)
    return build_ranking_table(df, show_all, order=order, selected=province), label or "", {} if label else {"display":"none"}, insight


@dash.callback(Output("national-trend-values", "children"), Input("national-trend", "figure"))
def _national_values(figure):
    return graph_summary(figure, "National success rate by year")


@dash.callback(Output("distribution-values", "children"), Input("distribution-graph", "figure"))
def _distribution_values(figure):
    return graph_summary(figure, "Recorded student results by score range")
