> Historical notes. See `README.md` for the current education-focused redesign,
> startup instructions, filter behavior and validation limits.

# EXETAT Dashboard Redesign

## Run

Run from the directory that contains both `exetat_dashboard/` and the existing
`database/` package:

```bash
python -m exetat_dashboard.app
```

The environment must provide `dash`, `plotly`, `pandas`, and the database driver
used by `database.db.get_connection()`. The database schema and connection
configuration are unchanged by this redesign.

## Preserved behavior

- Existing SQL query modules and database calls
- Existing callback IDs and filter semantics
- Province-name normalization and all 26 GeoJSON features
- Map, ranking, student, distribution, overview, and trend calculations
- Existing show-all controls

## Visual changes

- Dark national-intelligence design system and responsive layouts
- Persistent navigation with active-page indication
- Command-center header and active-year readout
- Dark, accessible Dash dropdown menus
- Refined KPI, leaderboard, student, map, distribution, and trend presentation
- Consistent Plotly typography, hover cards, grid lines, and color meaning
