# EXETAT Education Dashboard

A redesign of the existing Python/Dash application for families, educational
supervisors and policymakers. All three existing routes remain available:
Overview (`/`), Provinces (`/provinces`) and Schools (`/schools`).

## Run with your existing connection

Keep the updated `exetat_dashboard/` directory beside your existing `database/`
package. This ZIP does not include `database/db.py`, its MySQL driver/configuration,
credentials or an EXETAT database export. The application continues to call
`database.db.get_connection()`; it does not create or seed a database.

From the directory containing both packages, use the existing startup command:

```bash
python -m exetat_dashboard.app
```

If dependencies are not already installed in your environment:

```bash
python -m pip install -r exetat_dashboard/requirements.txt
```

For an existing uv project, retain its environment and connection dependencies;
run `uv run python -m exetat_dashboard.app` from the same parent directory.
The dashboard requires Python 3.10+ and the existing MySQL 8+ query capabilities.
The local browser address is `http://127.0.0.1:8050`.

When the connection is unavailable, the dashboard displays an explicit notice
and unavailable states. No sample educational results are substituted. Available
years, options and provinces are loaded at startup: restart after restoring the
connection or changing the available datasets.

## Using the dashboard

- **Overview:** select year → province → educational option and choose **Apply
  filters**. The summary shows the applied selection and warns about pending
  changes. **Reset filters** restores the configured initial selection.
- Totals, option leaders and the student distribution follow the applied province.
  The map and province ranking retain all provinces for comparison. The national
  trend retains all provinces and available years, with the applied option.
  Selecting a province outlines it on the map and places its trend first.
- Sort province results by highest success rate, lowest success rate or largest
  decline. The original expand/collapse controls remain available.
- **Provinces and Schools:** selectors update results immediately, as stated
  above the filters. School search remains bounded and restricted to the selected
  province. Rankings retain the top-ten preview and fifty-row pagination.
- Expand **View chart values** or **View all province values** for exact tabular
  alternatives. **Understanding these results** explains metrics and limitations.

## What changed

- One light design system: deep blue, white cards, readable labels and numbers,
  accessible text colors, visible keyboard focus, responsive layouts and semantic
  headings. Navigation marks the actual active page; only existing pages appear.
- Overview hierarchy: key outcomes → map and province comparison → national and
  province history → student results. Audience links lead to these existing views.
- Shared components in `components/ui.py` provide cards, labeled filters, loading
  states, metric guidance and chart-value tables. Detail pages use the same system.
- Province ranking is a real table. Student leaders are readable tables with
  explicit comparison labels. Student distributions use horizontal bars and
  counts. Charts use plain-language tooltips, percentage axes and restrained grids.
- The original 26-province GeoJSON and name-normalization functions are retained.
  Map colors use a fixed 0–100% scale, darker for higher rates. Gray means no data.
  Missing previous-year values display "Not available". Tooltips include schools,
  participants, successful students and change in percentage points.
- Map topology is served locally (`assets/world_110m.json`) so plotting does not
  require a third-party map request. No remote fonts or icon libraries are required.

## Limited query changes and their reasons

Existing joins, session totals, ranking rules, connection handling and detail-page
query architecture are preserved. No database writes or schema changes were made.

1. Add optional strict error propagation to existing overview readers so errors
   produce error states rather than apparently empty or zero results.
2. Preserve NULL success rates when no denominator exists, instead of converting
   them to 0%. Charts retain gaps and tables show a dash.
3. Add an optional province condition to the existing overview student-distribution
   query so its scope agrees with the selected province. Parameter binding remains
   in place. Scores above 100 are excluded as invalid; the 50–100 overview population,
   original name filter and result-row counting are otherwise retained.
4. Add one grouped national trend read in `queries/trends.py`. It uses the same
   session totals as national overview: `100 * SUM(reussites) / SUM(participants)`.
   Averaging province percentages would give an incorrect national rate.

The overview student distribution counts recorded result rows (including any
repeated rows in the source), not deduplicated student IDs. School distributions
retain their existing per-student deduplication and include valid scores below
50%. This distinction is documented rather than silently changing the source
population. Province/school historical queries retain their existing 2015–2023
window, clearly labeled in the interface. The new national and existing overview
province trends use the span of available years.

Legacy `SUCCESS_RATE_BUCKETS` identifiers are retained for the original unused
helper query. They are not used as the map legend: the displayed continuous legend
now matches the actual map scale.

## Verification

Run the isolated regression suite from the dashboard directory:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

The suite checks the original analytics behavior plus applied filters, resets,
query scope, weighted national trends, missing rates, map formatting and textual
chart alternatives. SQL is parsed using the MySQL dialect; the portable subset
runs against the project's existing isolated SQLite fixtures. These fixtures are
used only in tests, never by the application.

For read-only verification against your own MySQL database, run from the parent:

```bash
python -m exetat_dashboard.tools.validate_analytics
```

Completed checks for this delivery: **21 automated tests passed**. Browser
checks covered Overview, Provinces and Schools at widths of 1440, 768 and 390
pixels, including card/chart containment, horizontal overflow, label associations,
active navigation, the keyboard skip link, Apply/Reset and province-local school
selection. No browser JavaScript errors were detected. Populated browser checks
used only the project's existing isolated test fixtures; the production app was
also checked with the actual missing-connection state. No fixture server or
fixture screenshots are included as production content.

Live EXETAT data and MySQL integration could not be verified here because the
connection module and database were not included. Keyboard and layout checks do
not constitute a full screen-reader or WCAG conformance audit.

## Design review

- **Family:** the year and applied scope precede four explained metrics; school
  results are one navigation step away; percentages and percentage points are
  explained through keyboard-accessible disclosure controls.
- **Supervisor:** map, sortable province table and lowest-reported-rate note share
  one section. Participation counts and change are available in the map's table;
  missing rates are not ranked as zero.
- **Policymaker:** the national trend is visible before student-level detail;
  province trends and their exact values are available through progressive
  disclosure. Counts and rates remain distinct.

Text and interactive controls use the same tokens throughout `assets/style.css`.
Responsive breakpoints are 1100, 760 and 480 pixels. Narrow layouts stack sections
in reading order; wide tables scroll within their card. Reduced-motion preferences
are respected, and the main content has a keyboard skip link.

## Map asset attribution

`assets/world_110m.json` is the Plotly-distributed Natural Earth 1:110m topology,
retrieved from `https://cdn.plot.ly/world_110m.json`. Natural Earth data is public
domain; the file supplies the plotting topology. Province boundaries remain the
uploaded `data/26provinces_features.json` file, unchanged.

`ANALYTICS_NOTES.md` and `REDESIGN_NOTES.md` describe earlier work and are retained
for history; this README describes the current redesign.
