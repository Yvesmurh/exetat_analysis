"""
Dash application entry point.

Run from the project root (the parent directory of the exetat_dashboard/
package) so the `exetat_dashboard.*` absolute imports used throughout the
codebase resolve correctly:

    python -m exetat_dashboard.app
"""

import dash
from dash import dcc, html


app = dash.Dash(
    __name__,
    use_pages=True,
    suppress_callback_exceptions=True,
    title="EXETAT Education Dashboard",
    update_title="Loading education data…",
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}],
)
server = app.server

app.layout = html.Div(
    [
        dcc.Location(id="app-location"),
        html.A("Skip to main content", href="#main-content", className="skip-link"),
        html.Nav(
            [
                html.Div(
                    [html.Span("EX", className="nav-monogram"), html.Div([html.Strong("EXETAT Education Dashboard"), html.Small("DRC National Examination Analytics")])],
                    className="nav-brand",
                ),
                html.Div(
                    [
                        dcc.Link("Overview", href="/", id="nav-overview", className="nav-link"),
                        dcc.Link("Provinces", href="/provinces", id="nav-provinces", className="nav-link"),
                        dcc.Link("Schools", href="/schools", id="nav-schools", className="nav-link"),
                    ],
                    className="nav-links",
                ),
                html.Span("Education · Democratic Republic of the Congo", className="nav-context"),
            ],
            className="navbar", **{"aria-label": "Main navigation"},
        ),
        html.Main(dash.page_container, id="main-content", tabIndex=-1, className="page-content"),
        html.Footer("EXETAT · Examination outcomes for informed education decisions", className="site-footer"),
    ],
    className="app-shell",
)


@app.callback(
    dash.Output("nav-overview", "className"),
    dash.Output("nav-provinces", "className"),
    dash.Output("nav-schools", "className"),
    dash.Input("app-location", "pathname"),
)
def _highlight_active_navigation(pathname):
    active = {"/": 0, "/provinces": 1, "/schools": 2}.get(pathname, 0)
    return tuple("nav-link nav-link--active" if index == active else "nav-link" for index in range(3))


if __name__ == "__main__":
    app.run(debug=True)
