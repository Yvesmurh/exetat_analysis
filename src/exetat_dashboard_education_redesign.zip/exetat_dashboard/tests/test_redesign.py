"""Regression checks for UI scope, missing values and new trend aggregation.

Only the isolated fixture from conftest.py is used; no demo data ships to users.
"""
import json
import sys
import pandas as pd
import pytest
from conftest import call_callback
from exetat_dashboard.queries import helpers
from exetat_dashboard.queries.overview import get_national_overview
from exetat_dashboard.queries.province import get_province_stats, get_student_percentage_distribution
from exetat_dashboard.queries.trends import get_national_trend, get_province_trends
from exetat_dashboard.figures.map import create_choropleth, load_geojson
from exetat_dashboard.figures.analytics import build_scope_trend
from exetat_dashboard.components.ui import graph_summary


def test_apply_commits_one_selection_and_reset_restores_defaults(app):
    state = {'year-dropdown.value':2023, 'province-dropdown.value':'ALPHA', 'option-dropdown.value':'Math'}
    result = call_callback(app, 'applied-filters-store', {'apply-filters-btn.n_clicks':1}, 'apply-filters-btn.n_clicks', state)
    selection = result['applied-filters-store']['data']
    assert selection == {'year':2023,'province':'ALPHA','option':'Math'}
    # All expensive home data requests use the same applied selection.
    for entry in app.callback_map.values():
        if getattr(entry.get('callback'), '__module__', None) == 'pages.home' and any(i['id'] == 'applied-filters-store' for i in entry['inputs']):
            if 'filter-summary' not in str(entry['output']):
                assert not any(i['id'] in ['year-dropdown','province-dropdown','option-dropdown'] for i in entry['inputs'])
    reset = call_callback(app, 'applied-filters-store', {'reset-filters-btn.n_clicks':1}, 'reset-filters-btn.n_clicks', state)
    assert reset['applied-filters-store']['data'] == sys.modules['pages.home'].INITIAL_FILTERS


def test_home_queries_respect_scope_and_weighting(db):
    result = get_national_overview(2023, province='ALPHA', raise_on_error=True)
    assert result['success_rate'] == 30
    assert result['total_participants'] == 200
    distribution = get_student_percentage_distribution(2023, 'Math', 'ALPHA', raise_on_error=True)
    assert distribution['student_count'].sum() == 4  # original result-row population retained
    assert db[1][-1][1] == (2023,'Math','ALPHA')
    assert 'p26.name = %s' in db[1][-1][0]
    national = get_national_trend([2022,2023], 'Math').set_index('year')
    assert national.loc[2023,'success_rate'] == pytest.approx(100*160/210)
    assert len(db[1]) == 4  # overview 2, distribution 1, national trend 1


def test_unavailable_rates_remain_unavailable(db):
    assert get_national_overview(2021, province='ALPHA')['success_rate'] is None
    assert pd.isna(get_province_stats(2021).iloc[0]['success_rate'])
    assert pd.isna(get_province_trends(['ALPHA'],[2021]).iloc[0]['success_rate'])
    figure = build_scope_trend(get_national_trend([2021,2022]), [2021,2022])
    assert figure.data[0].y[0] is None


def test_home_callback_error_states_are_not_zero(app, monkeypatch):
    monkeypatch.setattr(helpers, 'get_connection', lambda: (_ for _ in ()).throw(RuntimeError('offline')))
    selection = {'year':2023, 'province':'ALPHA', 'option':'Math'}
    inputs = {'applied-filters-store.data':selection}
    result = call_callback(app,'overview-cards',inputs,'applied-filters-store.data')
    assert 'temporarily unavailable' in json.dumps(result)
    stats = call_callback(app,'province-stats-store',inputs,'applied-filters-store.data')
    assert stats['province-stats-store']['data'] == {'records':[],'error':True}
    distribution = call_callback(app,'distribution-graph',inputs,'applied-filters-store.data')
    assert 'temporarily unavailable' in json.dumps(distribution)


def test_home_callback_results_and_tables(app, db):
    selection = {'year':2023,'province':'ALPHA','option':'Toutes les options'}
    inputs = {'applied-filters-store.data':selection}
    overview = call_callback(app,'overview-cards',inputs,'applied-filters-store.data')
    assert '30.00%' in json.dumps(overview)
    assert 'Province Success Rate' in json.dumps(overview)
    students = call_callback(app,'top-students-container',inputs,'applied-filters-store.data')
    assert 'Foreign Leader' not in json.dumps(students)
    dist = call_callback(app,'distribution-graph',inputs,'applied-filters-store.data')
    trace = dist['distribution-graph']['figure']['data'][0]
    assert trace['x'] == [3,2,0,0,1]
    values = call_callback(app,'distribution-values',{'distribution-graph.figure':dist['distribution-graph']['figure']},'distribution-graph.figure')
    assert 'Recorded student results' in json.dumps(values)
    stats = call_callback(app,'province-stats-store',inputs,'applied-filters-store.data')['province-stats-store']['data']
    rank = call_callback(app,'ranking-table-container',{
        **inputs,'province-stats-store.data':stats,'ranking-show-all-store.data':False,'ranking-order.value':'lowest'}, 'ranking-order.value')
    assert 'Alpha' in json.dumps(rank['ranking-insight'])


def test_map_missing_values_fixed_scale_and_accessible_format():
    geo = load_geojson()
    name = geo['features'][0]['properties']['name']
    df = pd.DataFrame([{'province':name, 'success_rate_pct':0, 'participants':1000, 'delta_vs_prev_year':None}])
    figure = create_choropleth(df, value_col='success_rate_pct', selected_location=name,
        hover_cols=['participants','delta_vs_prev_year'], hover_labels={'participants':'Participants','delta_vs_prev_year':'Change from previous year'})
    assert len(figure.data[0].locations) == 26
    trace = figure.data[1]
    assert trace.zmin == 0 and trace.zmax == 100 and trace.z[0] == 0
    assert trace.customdata[0][0] == '1,000' and trace.customdata[0][1] == 'Not available'
    assert trace.marker.line.width[0] == 3
    assert 'Change from previous year' in trace.hovertemplate


def test_trend_text_values_do_not_need_another_query():
    fig = build_scope_trend(pd.DataFrame({'year':[2022,2023],'success_rate':[60,None]}),[2022,2023])
    table = graph_summary(fig.to_plotly_json(), 'Success rate by year')
    assert table.children[2].children[0].children[1].children == '60.00%'
    assert table.children[2].children[1].children[1].children == '—'
