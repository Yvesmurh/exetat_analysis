"""Shared presentation primitives; no queries or data assumptions."""
from dash import dcc, html
from exetat_dashboard.config import COLORS, DATA_AVAILABLE


def loading(children):
    # Uses the Loading API supported by the project's Dash 2.14+ range.
    return html.Div(dcc.Loading(children, type="circle", color=COLORS["primary"]),
                    className="loading-region", **{"aria-live": "polite"})


def card(number, title, subtitle, body, extra_class="", **kwargs):
    return html.Section([
        html.Div([html.H2(title, className="card-title"),
                  html.P(subtitle, className="card-subtitle")], className="card-header"),
        *(body if isinstance(body, list) else [body]),
    ], className=f"dash-card {extra_class}".strip(), **kwargs)


def field(component_id, label, options, value, **kwargs):
    return html.Div([
        html.Label(label, htmlFor=component_id, id=f"{component_id}-label", className="filter-label"),
        dcc.Dropdown(id=component_id, options=options, value=value, clearable=False,
                     optionHeight=44, **kwargs),
    ], className="filter-item")


def data_notice():
    if DATA_AVAILABLE:
        return None
    return html.Div([
        html.Strong("Education data is currently unavailable. "),
        "Please try again later. Results will appear when the data is available.",
    ], className="notice notice--warning", role="status")


def metric_help():
    return html.Details([
        html.Summary("Understanding these results"),
        html.Div([
            html.P([html.Strong("Success rate. "), "Successful students divided by participants, multiplied by 100. Larger groups contribute proportionally to the total."]),
            html.P([html.Strong("Percentage points (pts). "), "The difference between two percentages. A rise from 60% to 65% is an increase of 5 percentage points."]),
            html.P([html.Strong("Student scores. "), "A student's examination percentage is different from a school's or province's success rate. Recorded student results may cover fewer people than participation totals."]),
            html.P([html.Strong("Comparisons. "), "Changes compare the same option and area with the preceding calendar year, when available. A dash means the result is unavailable, not zero."]),
            html.P([html.Strong("Use results in context. "), "Consider participation, available years and local circumstances alongside rankings. Examination results alone do not describe every aspect of a school."]),
        ], className="help-body"),
    ], className="metric-help")


def graph_summary(figure, label):
    """Text/table alternative for a single-series chart, without another query."""
    if not figure or not figure.get("data"):
        return html.Span("No chart values available.", className="supporting-text")
    trace = figure["data"][0]
    xs, ys = trace.get("x", []), trace.get("y", [])
    rows = []
    horizontal = trace.get("orientation") == "h"
    for x, y in zip(xs, ys):
        key, value = (y, x) if horizontal else (x, y)
        formatted = "—" if value is None else (f"{value:,.0f}" if horizontal else f"{value:.2f}%")
        rows.append(html.Tr([html.Th(str(key), scope="row"), html.Td(formatted)]))
    return html.Table([html.Caption(label), html.Thead(html.Tr([
        html.Th("Score range" if horizontal else "Year", scope="col"),
        html.Th("Count" if horizontal else "Success rate", scope="col"),
    ])), html.Tbody(rows)], className="analytics-table")


def chart_values(component_id):
    return html.Details([html.Summary("View chart values"),
                         html.Div(id=component_id, className="analytics-table-scroll", tabIndex=0)],
                        className="chart-values")
