"""Province and school pages share the overview's design and explanations."""
from dash import dcc, html
from exetat_dashboard.config import AVAILABLE_YEARS, DEFAULT_YEAR, DEFAULT_OPTION, OPTIONS_LIST, PROVINCES_26
from exetat_dashboard.figures.analytics import empty_figure
from exetat_dashboard.components.ui import card, field as ui_field, loading, data_notice, metric_help, chart_values


def field(prefix, key, label, options, value, **kwargs):
    return ui_field(f"{prefix}-{key}", label, options, value, **kwargs)


def analytics_layout(prefix, school=False):
    entity = "School" if school else "Province"
    filters = [
        field(prefix, "year", "Year", [{"label":str(y), "value":y} for y in AVAILABLE_YEARS],
              DEFAULT_YEAR if DEFAULT_YEAR in AVAILABLE_YEARS else (AVAILABLE_YEARS[-1] if AVAILABLE_YEARS else None), placeholder="No years available"),
        field(prefix, "province", "Province", [{"label":p.title(), "value":p} for p in PROVINCES_26],
              PROVINCES_26[0] if PROVINCES_26 else None, placeholder="No provinces available"),
    ]
    if school:
        filters.append(field(prefix, "school", "School", [], None, searchable=True,
                             placeholder="Select a province, then search for a school"))
    filters.append(field(prefix, "option", "Educational option", [
        {"label":"All options" if o == DEFAULT_OPTION else o, "value":o} for o in OPTIONS_LIST], DEFAULT_OPTION))
    def graph(name):
        return loading(dcc.Graph(id=f"{prefix}-{name}", figure=empty_figure(),
                                  config={"displayModeBar":False,"responsive":True}, responsive=True, className="analytics-graph"))
    unit = "students" if school else "schools"
    return html.Div([
        html.Div([
            html.Div([html.Div("DRC education data", className="eyebrow"),
                      html.H1(f"{entity} performance", className="page-title"),
                      html.P("Find a school and understand its examination results." if school else
                             "Explore a province's results, compare its schools, and follow changes over time.", className="page-subtitle")]),
            html.Div([html.Span("Historical coverage"), html.Strong("2015–2023")], className="active-dataset"),
        ], className="dashboard-header"),
        data_notice(),
        html.Section([
            html.Div([html.H2("Analysis filters"), html.Span("Results update when you change a selection.")], className="filter-heading"),
            html.Div(filters, className="filters-row analytics-filters" + (" analytics-filters--school" if school else "")),
            html.Div(id=f"{prefix}-selection-note", className="analytics-selection-note", role="status"),
        ], className="analytics-filter-bar", **{"aria-label":"Analysis filters"}),
        card(1, f"{entity} results at a glance", "Selected year and educational option · change from the preceding year",
             loading(html.Div(id=f"{prefix}-overview"))),
        html.Div([
            card(2, "How has the success rate changed?", "2015–2023 · selected area and option · gaps indicate unavailable results", [
                graph("trend"), chart_values(f"{prefix}-trend-values")]),
            card(3, "Student performance distribution" if school else "How do schools compare?",
                 "Recorded students only · includes scores below 50%" if school else "Schools grouped by success rate · schools without an available rate are excluded", [
                     graph("distribution"), chart_values(f"{prefix}-distribution-values")]),
        ], className="analytics-pair"),
        card(4, "Student results" if school else "School results", "Ranked by individual examination score" if school else
             "Ranked by successful students as a percentage of participants · consider participation alongside the rate", [
            loading(html.Div(id=f"{prefix}-ranking")),
            html.Button(f"Show all {unit}", id=f"{prefix}-expand", n_clicks=0, className="ranking-toggle-btn", style={"display":"none"}),
            html.Div([
                html.Button("← Previous", id=f"{prefix}-previous", n_clicks=0, disabled=True, className="ranking-toggle-btn"),
                html.Span(id=f"{prefix}-page-label", role="status"),
                html.Button("Next →", id=f"{prefix}-next", n_clicks=0, disabled=True, className="ranking-toggle-btn"),
            ], id=f"{prefix}-pager", className="analytics-pager", style={"display":"none"}),
        ]),
        card(5, "Top performing students by option", "One best recorded score per option. Change compares the option's best score with the preceding year, not the same student's progress.",
             loading(html.Div(id=f"{prefix}-leaders"))),
        metric_help(),
        dcc.Store(id=f"{prefix}-paging", data={}),
    ], className="home-page analytics-page")
