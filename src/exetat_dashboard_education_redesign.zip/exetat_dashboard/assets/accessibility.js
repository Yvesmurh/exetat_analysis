/* Bridge labels to the editable input in Dash 2/3's legacy React Select.
   No data fetching, global keyboard handlers or changes to Dash state. */
(function () {
  let queued = false;
  function enhance() {
    queued = false;
    document.querySelectorAll('.dash-dropdown').forEach(function (dropdown) {
      const label = document.getElementById(dropdown.id + '-label');
      const input = dropdown.querySelector('input');
      if (label && input) {
        input.setAttribute('aria-labelledby', label.id);
        if (!input.id) input.id = dropdown.id + '-input';
        label.htmlFor = input.id;
      }
    });
    document.querySelectorAll('.nav-link').forEach(function (link) {
      if (link.classList.contains('nav-link--active')) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
    document.querySelectorAll('.loading-region').forEach(function (region) {
      const busy = !!region.querySelector('[data-dash-is-loading="true"]');
      region.setAttribute('aria-busy', String(busy));
      let status = region.querySelector('.loading-announcement');
      if (!status) {
        status = document.createElement('span');
        status.className = 'loading-announcement sr-only';
        status.setAttribute('role', 'status');
        region.appendChild(status);
      }
      const text = busy ? 'Loading education data…' : '';
      if (status.textContent !== text) status.textContent = text;
    });
  }
  const observer = new MutationObserver(function () {
    if (!queued) { queued = true; requestAnimationFrame(enhance); }
  });
  function start() {
    observer.observe(document.body, {childList:true, subtree:true, attributes:true,
      attributeFilter:['data-dash-is-loading', 'class']});
    enhance();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
