# Province and School Analytics

The existing Dash application now implements `/provinces` and `/schools`.
Both pages retain the Home page's navy/cyan theme, navigation, selectors,
KPI components, and database access architecture. No runtime data was fabricated,
and no database schema or records were changed.

## Run in the existing project

The uploaded ZIP contains `exetat_dashboard/`, but **does not contain the external
`database/db.py` module, database configuration, credentials, a schema dump, or a
dependency manifest**. Retain your existing `database/` package alongside this
updated `exetat_dashboard/` directory. Its `get_connection()` function remains
the sole source of database connections; no alternative database is configured.

From the directory containing both packages:

```bash
python -m pip install -r exetat_dashboard/requirements.txt
python -m exetat_dashboard.app
```

If managing dependencies with uv, retain the existing environment and its MySQL
driver. The supplied requirements record the dashboard's Python dependencies;
there is no new dependency required by the analytics pages beyond these.
Python 3.10+ is required by the existing type syntax. The queries use the same
CTE/window-function capabilities as the original top-student query (MySQL 8+).
If `database.db` cannot be imported or connected, the app can render empty
states; it does not substitute example data. Restart after correcting connection
configuration, because available years/options/provinces load at startup.

## Architecture and verified source relationships

`app.py` uses Dash Pages and the original navigation links. `config.py` loads
available years, options, and the names from `pr_after_reform26` through the
existing connection function. Query modules return aggregate dictionaries or
Pandas frames; presentation modules turn them into HTML or Plotly figures.
Page callbacks connect selectors to these functions.

These joins are verified against the uploaded working SQL, **not against a live
schema**. Legacy `ed_province` references in `TODO.txt` are not used.

| Source column | Related column | Purpose |
| --- | --- | --- |
| `exam_results.student_id` | `students.id` | Student identity/name |
| `exam_results.school_session_id` | `exetat_entry.id` | Exam session/year |
| `exetat_entry.school_id` | `schools.id` | School |
| `exetat_entry.option_id` | `options.id` | Educational option |
| `schools.province_id` | `educational_province.id` | Educational province |
| `educational_province.province_after_id` | `pr_after_reform26.id` | Post-reform province |

Province dropdown values are the exact database names, with title case used
only for display. School dropdown values are school IDs; labels include the
ID so identical school names remain distinguishable. No school/student name
is used as a join key, and no student denormalized province/year field is used.

## Changed files

| Files | Responsibility |
| --- | --- |
| `pages/province.py`, `pages/schools.py` | Layout selection and reactive callbacks |
| `components/analytics.py` | Shared filters, section cards, graph shells and paging controls |
| `queries/analytics.py` | Scoped weighted totals, historical rates and distributions |
| `queries/schools.py` | Bounded school search, school and student rankings |
| `queries/overview.py` | Extend existing option-leader query with optional school scope |
| `queries/helpers.py`, `config.py` | Preserve external connection; lazy import and explicit error handling for new queries |
| `queries/province.py` | Correct existing option/year parameter order in province statistics |
| `figures/analytics.py` | KPI reuse, comparison tables, trend and range figures |
| `utils/analytics_callbacks.py` | Isolated error rendering and bounded paging state |
| `assets/style.css` | Append styles scoped to `.analytics-page` |
| `tests/`, `pytest.ini`, requirements files | Isolated regression tests and dependency instructions |
| `tools/validate_analytics.py` | Read-only live validation command |

`app.py`, `pages/home.py`, the original figure modules, GeoJSON, province-name
normalization, and the original trend queries are unchanged. Original CSS
rules are unchanged; new rules are appended. `get_schools()` replaces an unused
placeholder and reports rates in 0–100 units, as documented in its docstring.
The other unused `get_school_detail()` placeholder has been removed.

## Calculation and display rules

- **Weighted rates:** `100.0 * SUM(ee.reussites) / NULLIF(SUM(ee.participants), 0)`.
  Overview, school rankings and trend queries aggregate session records without
  joining student results, preventing participant totals from being multiplied.
- **Distinct counts:** province cards count distinct school IDs; the school
  option card counts distinct option IDs in the selected year and option filter.
  Selecting one option restricts all current-year analytics, including this count.
- **Comparisons:** the previous year is exactly `current_year - 1`. Both years
  use identical province, school and option filters. Differences are percentage
  points, rounded for display. Zero is neutral; missing previous-year rates show
  “No previous-year data.” Undefined current rates display an em dash.
- **Option leaders:** reuse `get_top_students_by_option()` with the same scope
  applied to both CTEs. Equal scores resolve by name, student ID and session ID.
  One row is shown per option with a valid current-year result. The table includes
  the actual previous best score, not just the change. No current results produces
  an empty state; current leaders without a prior result retain their row.
- **Trend:** fixed 2015–2023 interval, computed separately per year. Missing years
  and zero denominators remain gaps (`connectgaps=False`). Current-year changes
  do not repeat this unchanged historical query.
- **Student ranking:** uses `exam_results.percentage`, never school success rate.
  Repeated result rows cannot repeat a student ID. If one student ID appears in
  multiple selected sessions/options for the school/year, use the highest score;
  ties use option/session ID. Different IDs with identical names remain distinct.
- **Distributions:** six bands: ≥90, [80,90), [70,80), [60,70), [50,60), <50.
  Labels state exclusive upper bounds to accommodate decimal scores. School bands
  use weighted school rates; student bands use the exact deduplicated ranking
  population. NULL and out-of-range percentages are excluded, not reclassified.
  Schools with undefined rates remain at the end of rankings and are excluded
  from the distribution.
- **Coverage:** student distributions describe available exam-result records.
  If the source stores only successful candidates, the dashboard does not infer
  missing failed candidates from participant totals.

## Interaction, scale and errors

Selectors update automatically using the existing year/default-option semantics.
The school selector searches only within the chosen province, returns up to 50
matches plus a valid retained selection, and safely resets when province changes.
Search terms and all filters/limits/offsets are SQL parameters.

Rankings initially display 10 rows. “Show all” enables 50-row pages with Previous
and Next controls and an internally scrolling table. SQL retrieves only one
extra row to determine whether Next is available; no complete result list is
stored in the browser. A filter change resets to the top 10. Stable score/name/ID
ordering prevents overlaps when data is unchanged; rows can move if the database
is updated between requests. An emptied final page returns to the first page.

Overview queries return at most two yearly aggregates. Trends return at most
nine years, distributions six buckets, and leaders one row per option. Rankings
use SQL `LIMIT/OFFSET`. Ranking/distribution window operations still process the
selected school/year on the server; they never download the national student
population. Existing indexes and constraints are retained. No speculative DDL
or cache with stale-result behavior was introduced. For a very large deployment,
inspect EXPLAIN plans against the real existing indexes before adding indexes;
late OFFSET pages and per-school window sorting can remain costly.

Each analytics section isolates query errors, displaying “Data is temporarily
unavailable. Please try again.” Other sections continue to render. A successful
query with no matching records displays “No data available for this selection.”
Available dropdown lists come from the existing startup configuration.

## Validation and remaining limits

Run the included regression tests from the dashboard directory:

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

The tests execute SQL against isolated SQLite fixtures using only columns
referenced by the source, while parsing each statement in MySQL dialect. They
cover weighted arithmetic, scope isolation, option/year binding, duplicate IDs,
missing data, zero denominators, fractional band boundaries, trend gaps,
pagination bounds/reset, routes, IDs, actual Dash callback POSTs, navigation
classes and component error isolation. Fixtures exist only under `tests/` and
are never loaded by the application.

Run the following from the parent directory **in your database environment**:

```bash
python -m exetat_dashboard.tools.validate_analytics
# Optional: choose the exact database province name, year, school and option.
python -m exetat_dashboard.tools.validate_analytics --year 2023
```

This command checks required columns, lists declared foreign-key relationships,
and executes the new queries with limited ranking output. It prints check status,
not student records, and makes no database changes.

Live MySQL execution, actual FK/index definitions and production-scale performance
could not be verified because the external connection package/server was absent.
All three routes and Dash layout/dependency endpoints were checked locally. A
visual browser check was attempted but the cloud browser blocked access to the
local app; desktop/mobile layout therefore still needs visual confirmation in
your running environment.
